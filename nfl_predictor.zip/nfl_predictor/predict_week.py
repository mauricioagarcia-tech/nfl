"""CLI: predicción de los partidos de una semana.

Ejemplos:
    python predict_week.py                       # semana actual (autodetectada)
    python predict_week.py --week 8
    python predict_week.py --week 8 --qb-out KC  # fuerza la baja del QB titular de KC
    python predict_week.py --week 8 --injuries-file mis_lesiones.csv
    python predict_week.py --week 8 --retrain --rolling-n 6
"""
from __future__ import annotations

import argparse
import logging

import numpy as np
import pandas as pd
from rich.console import Console
from rich.table import Table

import config as C
from data_loader import fetch_forecast, load_all
from features import build_dataset
from model import (apply_params, explain, load_model, market_prob, predict_margin,
                   predict_proba, report, train)

console = Console()
log = logging.getLogger("predict_week")

CONCEPTS = {
    "off_pass_epa": "EPA ofensivo por pase", "off_rush_epa": "EPA ofensivo por carrera",
    "off_sr": "Success Rate ofensivo", "off_cpoe": "CPOE del QB",
    "third_conv": "conversión en 3ª oportunidad", "fourth_conv": "conversión en 4ª oportunidad",
    "rz_td": "eficiencia en zona roja", "to_margin": "diferencial de pérdidas de balón",
    "def_pass_epa": "EPA defensivo vs. pase", "def_rush_epa": "EPA defensivo vs. carrera",
    "def_sr": "Success Rate defensivo", "def_cpoe": "CPOE permitido",
    "def_third_conv": "defensa en 3ª oportunidad", "def_rz_td": "defensa en zona roja",
    "streak": "racha", "last4_win": "forma reciente (últ. 4)", "last4_pd": "forma reciente (últ. 4)",
    "epa_trend": "tendencia de EPA (últ. 4)", "adj_net_epa": "EPA neto ajustado por rival",
    "hfa": "localía", "home_field": "localía", "rest_diff": "días de descanso",
    "div_game": "duelo divisional", "elo_diff": "rating Elo",
    "oa_pass": "EPA de pase ajustado por rival", "oa_sr": "Success Rate ajustado por rival",
    "oa_net_epa": "EPA neto ajustado por rival", "oa_st": "equipos especiales",
    "qb_value": "calidad del QB (EPA+CPOE)", "oa_rush": "EPA de carrera ajustado por rival",
}
SKIP = {"qb_delta", "home_qb_change", "away_qb_change", "inj_off", "inj_def", "indoor", "wind",
        "precip", "weather_pen", "weather_exposure", "temp_extreme", "is_neutral"}


def concept_of(feat: str) -> str | None:
    base = feat[2:] if feat.startswith("d_") else feat
    base = base[2:] if base[:2] in ("b_", "r_") else base
    if base in SKIP:
        return None
    return CONCEPTS.get(base)


# ---------------------------------------------------------------------------
# Insumos de la semana
# ---------------------------------------------------------------------------
def detect_week(schedules: pd.DataFrame, season: int) -> int:
    s = schedules[(schedules["season"] == season) & schedules["result"].isna()]
    return int(s["week"].min()) if len(s) else int(schedules[schedules["season"] == season]["week"].max())


def weather_overrides(games: pd.DataFrame, use_api: bool) -> dict:
    """Pronóstico para partidos aún no jugados. Retráctil: se asume cerrado si hay
    viento > umbral, precipitación o temperatura extrema."""
    out = {}
    for g in games[games["result"].isna()].itertuples():
        roof = g.roof if isinstance(g.roof, str) else None
        stadium_roof = C.STADIUMS.get(g.home_team, (0, 0, "outdoors"))[2]
        if g.location == "Neutral" or roof in ("dome", "closed") or not use_api:
            continue
        if roof is None and stadium_roof == "dome":
            continue
        fc = fetch_forecast(g.home_team, g.gameday, g.gametime)
        if fc is None:
            continue
        if stadium_roof == "retractable" and roof in (None, "open"):
            bad = fc["wind"] > C.WIND_THRESHOLD or fc["precip"] > 0 or not 45 <= fc["temp"] <= 88
            fc["roof"] = "closed" if bad else "open"
        else:
            fc["roof"] = roof or "outdoors"
        out[g.game_id] = fc
    return out


def manual_injuries(path: str | None, rosters: pd.DataFrame, season: int, week: int) -> pd.DataFrame:
    """CSV con columnas: team, full_name, position, report_status[, gsis_id]."""
    if not path:
        return pd.DataFrame()
    m = pd.read_csv(path)
    if "gsis_id" not in m:
        r = rosters[rosters["season"] == season].drop_duplicates(["team", "full_name"])
        m = m.merge(r[["team", "full_name", "gsis_id"]], on=["team", "full_name"], how="left")
    m["season"], m["week"] = season, week
    return m


# ---------------------------------------------------------------------------
# Factores clave
# ---------------------------------------------------------------------------
def key_factors(row: pd.Series, contrib: pd.Series, n_model: int = 2) -> list[str]:
    home, away = row["home_team"], row["away_team"]
    f = []
    for s, team in (("h", home), ("a", away)):
        if row[f"{s}_qb_change"] and row[f"{s}_qb_delta"] > 0.03:
            f.append(f"Baja de QB titular ({team}): {row[f'{s}_qb_exp']} → {row[f'{s}_qb_act']}")
        elif row[f"{s}_qb_change"] and row[f"{s}_qb_delta"] < -0.03:
            f.append(f"Mejora en QB ({team}): {row[f'{s}_qb_act']} por {row[f'{s}_qb_exp']}")
        if row[f"{s}_inj_off"] + row[f"{s}_inj_def"] > 0.012 and isinstance(row.get(f"{s}_inj_top"), str):
            f.append(f"Bajas clave {team}: {row[f'{s}_inj_top']}")
    if not row["indoor"]:
        if row["wind"] > 20:
            f.append(f"Factor viento > 20 mph ({row['wind']:.0f} mph)")
        elif row["wind"] > C.WIND_THRESHOLD:
            f.append(f"Viento de {row['wind']:.0f} mph penaliza el juego aéreo")
        if row["precip"] == 2:
            f.append("Precipitación intensa / nieve")
        elif row["precip"] == 1:
            f.append("Lluvia en el pronóstico")
    if row["is_neutral"]:
        f.append("Sede neutral (sin localía)")

    grouped: dict[str, float] = {}
    for feat, val in contrib.items():
        c = concept_of(feat)
        if c:
            grouped[c] = grouped.get(c, 0.0) + val
    for c, v in sorted(grouped.items(), key=lambda kv: -abs(kv[1]))[:n_model]:
        if abs(v) < 0.05:
            continue
        if c == "localía":
            continue  # se reporta abajo sólo cuando es atípica
        f.append(f"Ventaja de {c} ({home if v > 0 else away})")
    if not row["is_neutral"] and row["hfa"] >= 2.5:
        f.append(f"Localía fuerte de {home} (+{row['hfa']:.1f} pts históricos)")
    elif not row["is_neutral"] and row["hfa"] <= 0.8:
        f.append(f"Localía históricamente débil de {home} ({row['hfa']:+.1f} pts)")
    return [x for x in f if x]


# ---------------------------------------------------------------------------
# Motor reutilizable (lo usan la CLI, la página web y el actualizador automático)
# ---------------------------------------------------------------------------
def resolve_qb_start(items, rosters: pd.DataFrame) -> tuple[dict, list[str]]:
    """['BAL=Lamar Jackson', ...] o {'BAL': 'Lamar Jackson'} -> {'BAL': gsis_id}"""
    pairs = items.items() if isinstance(items, dict) else (i.split("=", 1) for i in items)
    out, missing = {}, []
    for team, name in pairs:
        r = rosters[rosters["full_name"].str.lower() == name.strip().strip('"').lower()]
        if r.empty:
            missing.append(name)
        else:
            out[team.upper().strip()] = r["gsis_id"].iloc[-1]
    return out, missing


def run_week(data, season: int, week: int, rolling_n: int = C.ROLLING_N,
             use_weather_api: bool = True, qb_out=(), qb_start=None,
             extra_injuries: pd.DataFrame | None = None, retrain: bool = False,
             status=lambda msg: None) -> tuple[pd.DataFrame, dict]:
    """Calcula las predicciones de una semana. Devuelve (tabla, bundle del modelo)."""
    games = data.schedules[(data.schedules["season"] == season) & (data.schedules["week"] == week)]
    if games.empty:
        raise ValueError(f"No hay partidos para {season} semana {week}")
    status("Consultando pronóstico del clima...")
    wx = weather_overrides(games, use_api=use_weather_api)

    wk_start = games["gameday"].min()
    if games["result"].notna().all():
        # semana terminada -> backtest honesto: sólo partidos anteriores a la semana
        status("Backtest: entrenando sólo con partidos previos a la semana (~3 min)...")
        bundle = train(data, save=False, rolling_n=rolling_n, until=wk_start)
    else:
        bundle = load_model()
        if (retrain or bundle is None or "params" not in bundle
                or bundle.get("rolling_n") != rolling_n):
            status("Entrenando modelo (búsqueda + validación anidada, ~3 min)...")
            bundle = train(data, rolling_n=rolling_n)

    qbs, _ = resolve_qb_start(qb_start or {}, data.rosters)
    apply_params(bundle["params"])  # mismos parámetros de features con los que se entrenó
    status("Calculando features...")
    df = build_dataset(data, rolling_n=rolling_n, weather_overrides=wx, target=(season, week),
                       manual_qb_out=[t.upper() for t in qb_out], manual_qb_start=qbs,
                       extra_injuries=extra_injuries)
    wk = df[(df["season"] == season) & (df["week"] == week)].copy()
    wk["p_home"] = predict_proba(bundle, wk)
    wk["margin"] = predict_margin(bundle, wk)
    wk["p_mkt"] = market_prob(wk)
    contrib = explain(bundle, wk)

    rows = []
    for idx, r in wk.iterrows():
        factors = key_factors(r, contrib.loc[idx])
        if pd.notna(r["p_mkt"]) and abs(r["p_home"] - r["p_mkt"]) >= 0.10:
            factors.append(f"Discrepancia con el mercado ({100 * (r['p_home'] - r['p_mkt']):+.0f} pts para {r['home_team']})")
        fav = r["home_team"] if r["p_home"] >= 0.5 else r["away_team"]
        rows.append({
            "season": season, "week": week, "game_id": r["game_id"], "gameday": r["gameday"].date(),
            "gametime": r.get("gametime"), "away": r["away_team"], "home": r["home_team"],
            "p_away": round(100 * (1 - r["p_home"]), 1), "p_home": round(100 * r["p_home"], 1),
            "pick": fav, "margen_local": None if pd.isna(r["margin"]) else round(float(r["margin"]), 1),
            "p_home_mercado": None if pd.isna(r["p_mkt"]) else round(100 * r["p_mkt"], 1),
            "spread_line": r["spread_line"], "qb_away": r.get("a_qb_act"), "qb_home": r.get("h_qb_act"),
            "wind": r["wind"], "indoor": r["indoor"], "factores": " | ".join(factors),
            "away_score": r["away_score"], "home_score": r["home_score"], "result": r["result"],
        })
    out = pd.DataFrame(rows)
    out.to_csv(C.OUTPUT_DIR / f"predicciones_{season}_w{week:02d}.csv", index=False)
    return out, bundle


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> None:
    ap = argparse.ArgumentParser(description="Predicción NFL de la semana")
    ap.add_argument("--week", type=int, help="semana (por defecto: la próxima sin jugar)")
    ap.add_argument("--season", type=int, default=C.CURRENT_SEASON)
    ap.add_argument("--retrain", action="store_true", help="reentrena aunque exista modelo")
    ap.add_argument("--rolling-n", type=int, default=C.ROLLING_N, help="ventana móvil (partidos)")
    ap.add_argument("--no-refresh", action="store_true", help="usa sólo la caché local")
    ap.add_argument("--no-weather-api", action="store_true", help="no consultar pronóstico")
    ap.add_argument("--qb-out", nargs="*", default=[], help="equipos sin su QB titular, p.ej. KC BUF")
    ap.add_argument("--qb-start", nargs="*", default=[],
                    help='titular forzado, p.ej. BAL="Lamar Jackson" (regreso de lesión)')
    ap.add_argument("--injuries-file", help="CSV con lesiones adicionales/actualizadas")
    ap.add_argument("--no-log", action="store_true", help="no guardar en el historial")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(levelname)s %(message)s")

    with console.status("Cargando datos de nflverse..."):
        data = load_all(refresh=not args.no_refresh, current_season=args.season)
    week = args.week or detect_week(data.schedules, args.season)
    extra = manual_injuries(args.injuries_file, data.rosters, args.season, week)
    with console.status("Calculando predicciones...") as st:
        res, bundle = run_week(data, args.season, week, args.rolling_n,
                               use_weather_api=not args.no_weather_api, qb_out=args.qb_out,
                               qb_start=args.qb_start, extra_injuries=extra, retrain=args.retrain,
                               status=lambda m: st.update(m))
    if not args.no_log:
        from tracker import log_predictions
        log_predictions(res, bundle)

    t = Table(title=f"NFL {args.season} · Semana {week} · modelo: {bundle['name']}", show_lines=True)
    for col, just in [("Partido (Visitante @ Local)", "left"), ("Visitante", "right"), ("Local", "right"),
                      ("Pick", "center"), ("Margen\nmodelo", "center"), ("Mercado\n(Vegas)", "center"),
                      ("Factores clave", "left"), ("Real (V-L)", "center")]:
        t.add_column(col, justify=just)
    for r in res.itertuples():
        sty = lambda p: "[green]" if p >= 50 else "[dim]"  # noqa: E731
        mg = "" if r.margen_local is None or pd.isna(r.margen_local) else f"{r.pick} {-abs(r.margen_local):.1f}"
        if pd.notna(r.p_home_mercado):
            mfav = r.home if r.p_home_mercado >= 50 else r.away
            mk = f"{mfav} {max(r.p_home_mercado, 100 - r.p_home_mercado):.0f}%"
            if pd.notna(r.spread_line) and r.spread_line != 0:
                mk += f"\n({mfav} -{abs(r.spread_line):.1f})"
        else:
            mk = "—"
        real = "" if pd.isna(r.result) else f"{int(r.away_score)}-{int(r.home_score)}"
        t.add_row(f"{r.away} @ {r.home}", f"{sty(r.p_away)}{r.p_away:.1f}%", f"{sty(r.p_home)}{r.p_home:.1f}%",
                  r.pick, mg, mk, "\n".join(f"• {x}" for x in r.factores.split(" | ") if x) or "—", real)
    console.print(t)
    console.print(f"[dim]Modelo entrenado con datos hasta {bundle['trained_through']}. "
                  f"CSV en output/.[/dim]")


if __name__ == "__main__":
    main()
