"""Configuración central del proyecto. Todos los pesos heurísticos viven aquí
para que puedas ajustarlos sin tocar la lógica."""
from pathlib import Path

# ---------------------------------------------------------------------------
# Temporadas
# ---------------------------------------------------------------------------
CURRENT_SEASON = 2026
TRAIN_SEASONS = list(range(2019, 2027))   # 2019-2026 (más historia = modelo más estable)
WARMUP_SEASONS = [2018]                         # sólo para "priors" de la semana 1 de 2019
HFA_START_SEASON = 2012                         # historial (sólo calendarios) para localía

# ---------------------------------------------------------------------------
# Rutas
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
CACHE_DIR = ROOT / "cache"
MODEL_DIR = ROOT / "models"
OUTPUT_DIR = ROOT / "output"
for _d in (CACHE_DIR, MODEL_DIR, OUTPUT_DIR):
    _d.mkdir(exist_ok=True)
MODEL_PATH = MODEL_DIR / "nfl_win_model.joblib"

# ---------------------------------------------------------------------------
# Feature engineering
# ---------------------------------------------------------------------------
ROLLING_N = 5            # ventana móvil (partidos) por defecto -> "últimas N semanas"
FORM_N = 4               # forma reciente: últimos 4 partidos
PRIOR_K = 4.0            # peso (en partidos) del prior de temporada anterior
PRIOR_REGRESS = 0.6      # 60% del valor previo del equipo, 40% media de la liga
HFA_K = 16.0             # shrinkage de la localía específica de cada equipo (en partidos)

# Garbage time: EPA/SR sólo con probabilidad de victoria entre estos límites
WP_MIN, WP_MAX = 0.05, 0.95
# EPA ajustado por rival (ridge)
ADJ_HALF_LIFE = 100.0    # días: un partido de hace 10 semanas pesa la mitad
ADJ_WINDOW_DAYS = 420    # ventana máxima hacia atrás (~1.2 temporadas)
ADJ_ALPHA = 8.0          # fuerza del encogimiento hacia la media
# Elo
ELO_MEAN, ELO_K, ELO_HFA, ELO_REVERT = 1505.0, 20.0, 48.0, 1 / 3

# Clima
WIND_THRESHOLD = 15.0    # mph a partir de las cuales se penaliza el pase
WIND_PEN_PER_MPH = 0.004 # EPA/dropback perdidos por cada mph por encima del umbral
PRECIP_PEN = {0: 0.0, 1: 0.02, 2: 0.05}   # 0 seco, 1 lluvia, 2 lluvia intensa / nieve
INDOOR_TEMP, INDOOR_WIND, INDOOR_HUMIDITY = 70.0, 0.0, 45.0

# Lesiones -------------------------------------------------------------------
# Probabilidad efectiva de que el jugador NO juegue según el reporte.
STATUS_PROB = {"Out": 1.0, "Doubtful": 0.8, "Questionable": 0.2}
# EPA/jugada que pierde la unidad cuando falta un titular de tiempo completo
# (se multiplica por su % de snaps reciente). Priors razonables, ajustables.
POS_WEIGHTS = {
    "WR": 0.018, "TE": 0.010, "RB": 0.008, "FB": 0.002,
    "T": 0.014, "G": 0.009, "C": 0.010, "OL": 0.010,
    "DE": 0.013, "OLB": 0.011, "EDGE": 0.013, "DT": 0.009, "NT": 0.008,
    "LB": 0.007, "ILB": 0.007, "MLB": 0.007,
    "CB": 0.013, "S": 0.008, "SS": 0.008, "FS": 0.008, "DB": 0.009,
}
OFF_POS = {"WR", "TE", "RB", "FB", "T", "G", "C", "OL"}
INJ_CAP_OFF, INJ_CAP_DEF = 0.08, 0.06
# QB
QB_REPLACEMENT_EPA = -0.12   # EPA/dropback de un QB de reemplazo
QB_SHRINK_K = 200.0          # dropbacks de shrinkage hacia el reemplazo
QB_STARTER_LOOKBACK = 3      # partidos para identificar al titular esperado
QB_HALF_LIFE = 365.0         # días: el rendimiento de hace un año pesa la mitad
QB_CPOE_WEIGHT = 0.004       # EPA/dropback por cada punto de CPOE en el compuesto
# Prior de un QB sin historial según su pick de draft: (pick máximo, EPA/dropback)
QB_DRAFT_PRIOR = [(10, -0.04), (32, -0.07), (100, -0.10)]

# ---------------------------------------------------------------------------
# Estadios: (lat, lon, tipo de techo). El techo "retractable" se decide con el
# pronóstico cuando nflverse no lo trae informado.
# ---------------------------------------------------------------------------
STADIUMS = {
    "ARI": (33.5276, -112.2626, "retractable"), "ATL": (33.7554, -84.4008, "retractable"),
    "BAL": (39.2780, -76.6227, "outdoors"),    "BUF": (42.7738, -78.7870, "outdoors"),
    "CAR": (35.2258, -80.8528, "outdoors"),    "CHI": (41.8623, -87.6167, "outdoors"),
    "CIN": (39.0955, -84.5161, "outdoors"),    "CLE": (41.5061, -81.6995, "outdoors"),
    "DAL": (32.7473, -97.0945, "retractable"), "DEN": (39.7439, -105.0201, "outdoors"),
    "DET": (42.3400, -83.0456, "dome"),        "GB":  (44.5013, -88.0622, "outdoors"),
    "HOU": (29.6847, -95.4107, "retractable"), "IND": (39.7601, -86.1639, "retractable"),
    "JAX": (30.3239, -81.6373, "outdoors"),    "KC":  (39.0489, -94.4839, "outdoors"),
    "LV":  (36.0909, -115.1833, "dome"),       "LAC": (33.9535, -118.3392, "dome"),
    "LA":  (33.9535, -118.3392, "dome"),       "MIA": (25.9580, -80.2389, "outdoors"),
    "MIN": (44.9737, -93.2581, "dome"),        "NE":  (42.0909, -71.2643, "outdoors"),
    "NO":  (29.9511, -90.0812, "dome"),        "NYG": (40.8135, -74.0745, "outdoors"),
    "NYJ": (40.8135, -74.0745, "outdoors"),    "PHI": (39.9008, -75.1675, "outdoors"),
    "PIT": (40.4468, -80.0158, "outdoors"),    "SF":  (37.4030, -121.9700, "outdoors"),
    "SEA": (47.5952, -122.3316, "outdoors"),   "TB":  (27.9759, -82.5033, "outdoors"),
    "TEN": (36.1665, -86.7713, "outdoors"),    "WAS": (38.9078, -76.8645, "outdoors"),
}
