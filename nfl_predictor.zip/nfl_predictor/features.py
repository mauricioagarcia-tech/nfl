"""Feature engineering: EPA, éxito, CPOE, eficiencia, forma, localía, clima y lesiones.

Principio anti-leakage: todas las métricas de un partido se calculan con el "estado"
del equipo DESPUÉS de su último partido completado y ANTES de la fecha del partido
(`merge_asof(..., allow_exact_matches=False)`). Así el mismo código sirve para
entrenar con partidos pasados y para predecir partidos futuros.

Convención: toda feature `d_*` es "local menos visitante" orientada para que un valor
POSITIVO favorezca al LOCAL (en métricas defensivas se invierte el signo).
"""
from __future__ import annotations

import bisect
import re

import numpy as np
import pandas as pd

import config as C

# ---------------------------------------------------------------------------
# 1. Estadísticas por equipo-partido (play-by-play)
# ---------------------------------------------------------------------------
BASE = ["epa_sum", "plays", "pass_epa_sum", "pass_n", "rush_epa_sum", "rush_n",
        "succ_sum", "cpoe_sum", "cpoe_n", "third_conv", "third_att",
        "fourth_conv", "fourth_att", "rz_td", "rz_n", "giveaways", "st_epa_sum"]

# métrica -> (numerador, denominador). Las def_* son lo que el equipo PERMITE.
METRICS = {
    "off_epa": ("epa_sum", "plays"), "off_pass_epa": ("pass_epa_sum", "pass_n"),
    "off_rush_epa": ("rush_epa_sum", "rush_n"), "off_sr": ("succ_sum", "plays"),
    "off_cpoe": ("cpoe_sum", "cpoe_n"), "pass_rate": ("pass_n", "plays"),
    "third_conv": ("third_conv", "third_att"), "fourth_conv": ("fourth_conv", "fourth_att"),
    "rz_td": ("rz_td", "rz_n"), "to_margin": ("to_margin", "games"),
    "def_epa": ("def_epa_sum", "def_plays"), "def_pass_epa": ("def_pass_epa_sum", "def_pass_n"),
    "def_rush_epa": ("def_rush_epa_sum", "def_rush_n"), "def_sr": ("def_succ_sum", "def_plays"),
    "def_cpoe": ("def_cpoe_sum", "def_cpoe_n"),
    "def_third_conv": ("def_third_conv", "def_third_att"),
    "def_rz_td": ("def_rz_td", "def_rz_n"),
}
# métricas donde "más bajo es mejor" -> se invierte el signo del diferencial
LOWER_IS_BETTER = {"def_epa", "def_pass_epa", "def_rush_epa", "def_sr", "def_cpoe",
                   "def_third_conv", "def_rz_td"}
MODEL_METRICS = [m for m in METRICS if m not in ("pass_rate", "off_epa", "def_epa")]


def team_game_stats(pbp: pd.DataFrame, schedules: pd.DataFrame) -> pd.DataFrame:
    """Una fila por (game_id, team) de partidos completados, con numeradores/denominadores."""
    p = pbp[pbp["posteam"].notna()].copy()
    plays = p[p["play_type"].isin(["pass", "run"]) & p["epa"].notna()].copy()
    is_pass = plays["pass"] == 1
    is_rush = (plays["rush"] == 1) & ~is_pass
    plays = plays.assign(
        epa_sum=plays["epa"], plays=1,
        pass_epa_sum=plays["epa"].where(is_pass, 0.0), pass_n=is_pass.astype(int),
        rush_epa_sum=plays["epa"].where(is_rush, 0.0), rush_n=is_rush.astype(int),
        succ_sum=plays["success"].fillna(0), cpoe_sum=plays["cpoe"].fillna(0),
        cpoe_n=plays["cpoe"].notna().astype(int),
    )
    key = ["game_id", "posteam"]
    # Garbage time fuera: EPA/SR/CPOE sólo con jugadas en situación competitiva
    neutral = plays["wp"].between(C.WP_MIN, C.WP_MAX) | plays["wp"].isna() if "wp" in plays else True
    agg = plays[neutral].groupby(key)[["epa_sum", "plays", "pass_epa_sum", "pass_n", "rush_epa_sum",
                              "rush_n", "succ_sum", "cpoe_sum", "cpoe_n"]].sum()

    downs = p.groupby(key)[["third_down_converted", "third_down_failed",
                            "fourth_down_converted", "fourth_down_failed", "interception"]].sum()
    agg["third_conv"] = downs["third_down_converted"]
    agg["third_att"] = downs["third_down_converted"] + downs["third_down_failed"]
    agg["fourth_conv"] = downs["fourth_down_converted"]
    agg["fourth_att"] = downs["fourth_down_converted"] + downs["fourth_down_failed"]

    # Pérdidas: intercepciones + balones sueltos perdidos por ESTE equipo
    fum = (p[p["fumble_lost"] == 1].groupby(["game_id", "fumbled_1_team"]).size()
           .rename_axis(key))
    agg["giveaways"] = downs["interception"].add(fum, fill_value=0).reindex(agg.index).fillna(0)

    # Zona roja: drives que llegan a la yarda 20 rival y terminan en TD
    plays["rz"] = (plays["yardline_100"] <= 20).astype(int)
    plays["td"] = (plays["fixed_drive_result"] == "Touchdown").astype(int)
    drv = plays.groupby(key + ["fixed_drive"])[["rz", "td"]].max()
    drv = drv[drv["rz"] == 1].groupby(key).agg(rz_n=("rz", "size"), rz_td=("td", "sum"))
    # Equipos especiales: EPA de goles de campo, PAT, despejes y patadas de salida
    st = p[p["play_type"].isin(["field_goal", "punt", "kickoff", "extra_point"]) & p["epa"].notna()]
    agg["st_epa_sum"] = st.groupby(key)["epa"].sum().reindex(agg.index).fillna(0.0)
    agg = agg.join(drv).fillna({"rz_n": 0, "rz_td": 0}).reset_index()
    agg = agg.rename(columns={"posteam": "team"})

    # Defensa = ataque del rival
    opp = agg.rename(columns={"team": "opp", **{c: f"def_{c}" for c in BASE}})
    sides = _game_sides(schedules[schedules["result"].notna()])
    tg = sides.merge(agg, on=["game_id", "team"]).merge(opp, on=["game_id", "opp"])
    tg["to_margin"] = tg["def_giveaways"] - tg["giveaways"]
    tg["games"] = 1
    tg["st_net"] = tg["st_epa_sum"] - tg["def_st_epa_sum"]   # EPA neto de equipos especiales
    tg["net_epa"] = tg["epa_sum"] / tg["plays"] - tg["def_epa_sum"] / tg["def_plays"]
    return tg.sort_values(["team", "gameday", "game_id"]).reset_index(drop=True)


def _game_sides(s: pd.DataFrame) -> pd.DataFrame:
    """Calendario -> dos filas por partido (perspectiva de cada equipo)."""
    cols = ["game_id", "season", "week", "game_type", "gameday"]
    h = s[cols + ["home_team", "away_team", "home_score", "away_score"]].rename(
        columns={"home_team": "team", "away_team": "opp", "home_score": "pf", "away_score": "pa"})
    a = s[cols + ["away_team", "home_team", "away_score", "home_score"]].rename(
        columns={"away_team": "team", "home_team": "opp", "away_score": "pf", "home_score": "pa"})
    h["is_home"], a["is_home"] = 1, 0
    out = pd.concat([h, a], ignore_index=True)
    out["margin"] = out["pf"] - out["pa"]
    out["win"] = np.sign(out["margin"]).map({1: 1.0, 0: 0.5, -1: 0.0})
    return out


# ---------------------------------------------------------------------------
# 2. Estado pos-partido de cada equipo (acumulado de temporada, móvil y forma)
# ---------------------------------------------------------------------------
def _slope(arr: np.ndarray) -> float:
    if len(arr) < 2:
        return 0.0
    return float(np.polyfit(np.arange(len(arr)), arr, 1)[0])


def team_states(tg: pd.DataFrame, rolling_n: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    tg = tg.copy()
    cols = sorted({c for pair in METRICS.values() for c in pair})
    g_season = tg.groupby(["team", "season"])
    g_team = tg.groupby("team")
    st = tg[["team", "season", "gameday", "game_id"]].copy()
    st["n_season"] = g_season.cumcount() + 1

    cum = g_season[cols].cumsum()
    roll = g_team[cols].rolling(rolling_n, min_periods=1).sum().reset_index(level=0, drop=True)
    for m, (num, den) in METRICS.items():
        st[f"std_{m}"] = cum[num] / cum[den].replace(0, np.nan)
        st[f"roll_{m}"] = roll[num] / roll[den].replace(0, np.nan)

    # Forma reciente (dentro de la temporada)
    st["last4_win"] = g_season["win"].rolling(C.FORM_N, min_periods=1).mean().reset_index(level=[0, 1], drop=True)
    st["last4_pd"] = g_season["margin"].rolling(C.FORM_N, min_periods=1).mean().reset_index(level=[0, 1], drop=True)
    st["epa_trend"] = (g_season["net_epa"].rolling(C.FORM_N, min_periods=2)
                       .apply(_slope, raw=True).reset_index(level=[0, 1], drop=True).fillna(0))
    streak, prev = [], (None, None, 0)
    for team, season, w in zip(tg["team"], tg["season"], tg["win"]):
        s = prev[2] if (team, season) == prev[:2] else 0
        if w == 1:
            s = s + 1 if s > 0 else 1
        elif w == 0:
            s = s - 1 if s < 0 else -1
        else:
            s = 0
        streak.append(s)
        prev = (team, season, s)
    st["streak"] = streak

    # Valores finales de cada temporada -> prior de la siguiente
    final = st.groupby(["team", "season"]).last()[[f"std_{m}" for m in METRICS]]
    league = final.groupby(level="season").mean()
    final.columns = [c.replace("std_", "") for c in final.columns]
    league.columns = final.columns
    reg = final.copy()
    for m in final.columns:
        lg = final.index.get_level_values("season").map(league[m])
        reg[m] = C.PRIOR_REGRESS * final[m] + (1 - C.PRIOR_REGRESS) * np.asarray(lg)
    prior = reg.reset_index()
    prior["season"] += 1  # el prior de la temporada S es la temporada S-1
    prior = prior.rename(columns={m: f"prior_{m}" for m in METRICS})
    return st.sort_values("gameday").reset_index(drop=True), prior


def side_features(sides: pd.DataFrame, states: pd.DataFrame, prior: pd.DataFrame) -> pd.DataFrame:
    """Para cada (partido, equipo) toma el último estado previo al partido y mezcla
    temporada actual con el prior: blended = (n*actual + K*prior)/(n+K)."""
    left = sides.sort_values("gameday")
    st = states.rename(columns={"season": "st_season", "game_id": "last_game_id"})
    st = st.drop(columns="gameday").assign(st_date=states["gameday"]).sort_values("st_date")
    left = left.assign(team=left["team"].astype(object))
    st = st.assign(team=st["team"].astype(object))
    out = pd.merge_asof(left, st, left_on="gameday", right_on="st_date", by="team",
                        allow_exact_matches=False)
    out = out.merge(prior, on=["team", "season"], how="left")
    same = out["st_season"] == out["season"]
    n = np.where(same, out["n_season"], 0.0)
    for m in METRICS:
        cur = out[f"std_{m}"].where(same)
        pr = out[f"prior_{m}"].fillna(cur)  # sin prior (primer año cargado) -> sólo actual
        cur = cur.fillna(pr)                # denominador 0 en la temporada -> prior
        out[f"b_{m}"] = (cur.fillna(0) * n + C.PRIOR_K * pr) / (n + C.PRIOR_K)
        out[f"r_{m}"] = out[f"roll_{m}"].fillna(out[f"b_{m}"])
    out["streak"] = out["streak"].where(same, 0).fillna(0)
    out["last4_win"] = out["last4_win"].where(same, 0.5).fillna(0.5)
    out["last4_pd"] = out["last4_pd"].where(same, 0.0).fillna(0.0)
    out["epa_trend"] = out["epa_trend"].where(same, 0.0).fillna(0.0)
    out["games_played"] = n
    keep = (["game_id", "team"] + [f"{w}_{m}" for w in ("b", "r") for m in METRICS]
            + ["streak", "last4_win", "last4_pd", "epa_trend", "games_played"])
    return out[keep]


# ---------------------------------------------------------------------------
# 3. Localía ajustada por historial del equipo en su estadio
# ---------------------------------------------------------------------------
def home_field_advantage(schedules: pd.DataFrame) -> pd.DataFrame:
    s = schedules.sort_values("gameday")
    done = s[s["result"].notna() & (s["location"] != "Neutral")]
    rows = pd.concat([
        pd.DataFrame({"team": done["home_team"], "gameday": done["gameday"],
                      "hm": done["result"], "hn": 1, "am": 0.0, "an": 0}),
        pd.DataFrame({"team": done["away_team"], "gameday": done["gameday"],
                      "hm": 0.0, "hn": 0, "am": -done["result"], "an": 1}),
    ]).sort_values(["team", "gameday"])
    rows[["hm", "hn", "am", "an"]] = rows.groupby("team")[["hm", "hn", "am", "an"]].cumsum()
    rows = rows.groupby(["team", "gameday"]).last().reset_index().sort_values("gameday")

    lg = done[["gameday", "result"]].copy()
    lg["lg_hfa"] = lg["result"].expanding().mean()
    lg = lg.groupby("gameday").last().reset_index()[["gameday", "lg_hfa"]]

    g = s[["game_id", "gameday", "home_team", "location"]].rename(columns={"home_team": "team"})
    g["team"], rows["team"] = g["team"].astype(object), rows["team"].astype(object)
    g = pd.merge_asof(g, rows, on="gameday", by="team", allow_exact_matches=False)
    g = pd.merge_asof(g, lg, on="gameday", allow_exact_matches=False)
    g["lg_hfa"] = g["lg_hfa"].fillna(1.8)
    raw = (g["hm"] / g["hn"] - g["am"] / g["an"]) / 2
    n_eff = 2 / (1 / g["hn"] + 1 / g["an"])
    g["hfa"] = ((n_eff * raw).fillna(0) + C.HFA_K * g["lg_hfa"]) / (n_eff.fillna(0) + C.HFA_K)
    g["is_neutral"] = (g["location"] == "Neutral").astype(int)
    g.loc[g["is_neutral"] == 1, "hfa"] = 0.0
    return g[["game_id", "hfa", "is_neutral"]]


# ---------------------------------------------------------------------------
# 4. Clima
# ---------------------------------------------------------------------------
_HUM = re.compile(r"Humidity:\s*(\d+)")


def _precip_level(text) -> int:
    if not isinstance(text, str):
        return 0
    t = text.lower()
    if any(k in t for k in ("snow", "heavy rain", "thunder", "storm", "sleet")):
        return 2
    if any(k in t for k in ("rain", "shower", "drizzle")) and "no rain" not in t:
        return 1
    return 0


def weather_features(schedules: pd.DataFrame, pbp: pd.DataFrame,
                     overrides: dict | None = None) -> pd.DataFrame:
    w = schedules[["game_id", "home_team", "roof", "temp", "wind"]].copy()
    txt = pbp.dropna(subset=["weather"]).groupby("game_id")["weather"].first()
    w["weather_txt"] = w["game_id"].map(txt)
    w["humidity"] = w["weather_txt"].str.extract(_HUM, expand=False).astype(float)
    w["precip"] = w["weather_txt"].map(_precip_level)
    # techo desconocido (retráctil sin informar) -> tipo del estadio local
    stadium_roof = w["home_team"].map(lambda t: C.STADIUMS.get(t, (0, 0, "outdoors"))[2])
    w["roof"] = w["roof"].fillna(stadium_roof.replace({"retractable": "closed"}))
    for gid, ov in (overrides or {}).items():
        for k, v in ov.items():
            if k in ("temp", "wind", "humidity", "precip", "roof"):
                w.loc[w["game_id"] == gid, k] = v
    w["indoor"] = w["roof"].isin(["dome", "closed"]).astype(int)
    ind = w["indoor"] == 1
    w.loc[ind, ["temp", "wind", "humidity", "precip"]] = [C.INDOOR_TEMP, C.INDOOR_WIND,
                                                         C.INDOOR_HUMIDITY, 0]
    w["temp"] = w["temp"].fillna(60.0)
    w["wind"] = w["wind"].fillna(7.0)
    w["humidity"] = w["humidity"].fillna(60.0)
    w["precip"] = w["precip"].fillna(0).astype(int)
    w["high_wind"] = (w["wind"] > C.WIND_THRESHOLD).astype(int)
    w["temp_extreme"] = (w["temp"] - 60).abs().clip(lower=20) - 20   # >80F o <40F
    w["weather_pen"] = (C.WIND_PEN_PER_MPH * (w["wind"] - C.WIND_THRESHOLD).clip(lower=0)
                        + w["precip"].map(C.PRECIP_PEN)) * (1 - w["indoor"])
    return w[["game_id", "roof", "indoor", "temp", "wind", "humidity", "precip",
              "high_wind", "temp_extreme", "weather_pen"]]


# ---------------------------------------------------------------------------
# 5. Lesiones: QB titular + resto de posiciones clave
# ---------------------------------------------------------------------------
class QBModel:
    """Valor de cada QB (v2) = compuesto EPA + CPOE por dropback:
      * ponderado por recencia (vida media QB_HALF_LIFE días: lo reciente pesa más),
      * con shrinkage hacia un prior que depende de su posición en el draft
        (un top-10 novato no es lo mismo que un QB no drafteado),
      * value = EPA_hat + QB_CPOE_WEIGHT * CPOE_hat  (el CPOE es más estable y predictivo).
    Titular esperado = líder en dropbacks de los últimos QB_STARTER_LOOKBACK partidos."""

    def __init__(self, pbp: pd.DataFrame, rosters: pd.DataFrame | None = None):
        db = pbp[(pbp["qb_dropback"] == 1) & pbp["epa"].notna() & pbp["passer_id"].notna()]
        db = db.assign(cpoe_s=db["cpoe"].fillna(0), cpoe_n=db["cpoe"].notna().astype(int))
        g = (db.groupby(["passer_id", "game_id", "game_date", "posteam"])
             .agg(epa=("epa", "sum"), n=("epa", "size"), cpoe_s=("cpoe_s", "sum"),
                  cpoe_n=("cpoe_n", "sum"), name=("passer", "first")).reset_index())
        g["game_date"] = pd.to_datetime(g["game_date"])
        self.names = g.groupby("passer_id")["name"].last().to_dict()
        self.draft = {}
        if rosters is not None and "draft_number" in rosters:
            r = rosters[rosters["position"] == "QB"].dropna(subset=["gsis_id"])
            self.draft = r.groupby("gsis_id")["draft_number"].max().to_dict()
            rn = r.groupby("gsis_id")[["first_name", "last_name"]].last().dropna()
            short = rn["first_name"].astype(str).str[0] + "." + rn["last_name"].astype(str)
            self.names = {**short.to_dict(), **self.names}
        self._qb = {}
        for pid, d in g.sort_values("game_date").groupby("passer_id"):
            self._qb[pid] = (list(d["game_date"]), d["game_date"].values.astype("datetime64[D]"),
                             d["epa"].values, d["n"].values, d["cpoe_s"].values, d["cpoe_n"].values)
        self._team = {}
        for team, d in g.sort_values("game_date").groupby("posteam"):
            dates, games = [], []
            for (_, gdate), x in d.groupby(["game_id", "game_date"], sort=False):
                dates.append(gdate)
                games.append(dict(zip(x["passer_id"], x["n"])))
            order = np.argsort(dates, kind="stable")
            self._team[team] = ([dates[i] for i in order], [games[i] for i in order])

    def prior(self, pid) -> float:
        dn = self.draft.get(pid)
        if dn is None or pd.isna(dn):
            return C.QB_REPLACEMENT_EPA
        for cut, val in C.QB_DRAFT_PRIOR:
            if dn <= cut:
                return val
        return C.QB_REPLACEMENT_EPA

    def dropbacks_before(self, pid, date) -> int:
        if pid not in self._qb:
            return 0
        dates, _, _, n, _, _ = self._qb[pid]
        return int(n[:bisect.bisect_left(dates, date)].sum())

    def value(self, pid, date) -> float:
        if not isinstance(pid, str):
            return C.QB_REPLACEMENT_EPA
        pr = self.prior(pid)
        if pid not in self._qb:
            return pr
        dates, days, e, n, cs, cn = self._qb[pid]
        i = bisect.bisect_left(dates, date)
        if i == 0:
            return pr
        age = (np.datetime64(pd.Timestamp(date).date()) - days[:i]).astype(float)
        w = 0.5 ** (age / C.QB_HALF_LIFE)
        epa_hat = ((w * e[:i]).sum() + C.QB_SHRINK_K * pr) / ((w * n[:i]).sum() + C.QB_SHRINK_K)
        cpoe_hat = (w * cs[:i]).sum() / ((w * cn[:i]).sum() + C.QB_SHRINK_K)
        return float(epa_hat + C.QB_CPOE_WEIGHT * cpoe_hat)

    def expected_starter(self, team, date):
        if team not in self._team:
            return None
        dates, games = self._team[team]
        i = bisect.bisect_left(dates, date)
        tot: dict = {}
        for d in games[max(0, i - C.QB_STARTER_LOOKBACK):i]:
            for k, v in d.items():
                tot[k] = tot.get(k, 0) + v
        return max(tot, key=tot.get) if tot else None

    def name(self, pid) -> str:
        return self.names.get(pid, "QB suplente") if isinstance(pid, str) else "QB suplente"


def nonqb_injury_loss(injuries: pd.DataFrame, snaps: pd.DataFrame,
                      rosters: pd.DataFrame) -> pd.DataFrame:
    """Pérdida de EPA/jugada (ofensiva y defensiva) por (season, week, team)."""
    cols = ["season", "week", "team", "inj_off", "inj_def", "inj_top"]
    if injuries.empty:
        return pd.DataFrame(columns=cols)
    inj = injuries[injuries["report_status"].isin(C.STATUS_PROB) & (injuries["position"] != "QB")].copy()
    inj = inj.drop_duplicates(["season", "week", "team", "gsis_id"])
    idmap = rosters.dropna(subset=["gsis_id", "pfr_id"]).drop_duplicates("gsis_id")
    inj["pfr_id"] = inj["gsis_id"].map(idmap.set_index("gsis_id")["pfr_id"])
    inj["t"] = (inj["season"] * 100 + inj["week"]).astype("int64")

    sn = snaps[["pfr_player_id", "season", "week", "offense_pct", "defense_pct"]].copy()
    sn["share"] = sn[["offense_pct", "defense_pct"]].max(axis=1)
    sn["t"] = (sn["season"] * 100 + sn["week"]).astype("int64")
    sn = sn.sort_values(["pfr_player_id", "t"])
    sn["share4"] = sn.groupby("pfr_player_id")["share"].transform(
        lambda s: s.rolling(4, min_periods=1).mean())
    sn = sn.rename(columns={"pfr_player_id": "pfr_id"})[["pfr_id", "t", "share4"]].sort_values("t")

    inj = inj.dropna(subset=["pfr_id"]).sort_values("t")
    inj["pfr_id"], sn["pfr_id"] = inj["pfr_id"].astype(str).astype(object), sn["pfr_id"].astype(str).astype(object)
    inj = pd.merge_asof(inj, sn, on="t", by="pfr_id", allow_exact_matches=False)
    inj["share4"] = inj["share4"].fillna(0)
    inj["loss"] = (inj["position"].map(C.POS_WEIGHTS).fillna(0) * inj["share4"]
                   * inj["report_status"].map(C.STATUS_PROB))
    inj["side"] = np.where(inj["position"].isin(C.OFF_POS), "inj_off", "inj_def")
    agg = inj.pivot_table(index=["season", "week", "team"], columns="side", values="loss",
                          aggfunc="sum", fill_value=0).reset_index()
    for c in ("inj_off", "inj_def"):
        if c not in agg:
            agg[c] = 0.0
    agg["inj_off"] = agg["inj_off"].clip(upper=C.INJ_CAP_OFF)
    agg["inj_def"] = agg["inj_def"].clip(upper=C.INJ_CAP_DEF)
    inj["lbl"] = inj["full_name"].astype(str) + " (" + inj["position"].astype(str) + ")"
    top = (inj[inj["loss"] > 0.004].sort_values("loss", ascending=False)
           .groupby(["season", "week", "team"])["lbl"]
           .agg(lambda s: ", ".join(s.head(3))).rename("inj_top").reset_index())
    agg = agg.merge(top, on=["season", "week", "team"], how="left")
    return agg[cols]


def qb_features(schedules: pd.DataFrame, qbm: QBModel, injuries: pd.DataFrame,
                rosters: pd.DataFrame, target: tuple[int, int] | None,
                manual_qb_out: list[str] | None,
                manual_qb_start: dict | None = None) -> pd.DataFrame:
    """Para partidos jugados: titular real (calendario) vs titular esperado.
    Para la semana objetivo: titular proyectado; si figura Out/Doubtful en el
    reporte (o por --qb-out) se reemplaza por el mejor QB disponible del roster."""
    out_ids = set()
    if target is not None and not injuries.empty:
        r = injuries[(injuries["season"] == target[0]) & (injuries["week"] == target[1])
                     & (injuries["position"] == "QB") & injuries["report_status"].isin(["Out", "Doubtful"])]
        out_ids = set(r["gsis_id"])
    manual = set(manual_qb_out or [])
    rows = []
    for g in schedules.itertuples():
        is_target = target is not None and (g.season, g.week) == target
        for side in ("home", "away"):
            team, date = getattr(g, f"{side}_team"), g.gameday
            exp = qbm.expected_starter(team, date)
            act = getattr(g, f"{side}_qb_id")
            act = act if isinstance(act, str) else exp
            if is_target and manual_qb_start and team in manual_qb_start:
                act = manual_qb_start[team]  # titular forzado (p.ej. regreso de lesión)
            if is_target and (act in out_ids or team in manual):
                excl = {act} | out_ids
                if team in manual:
                    excl.add(exp)
                r = rosters[(rosters["season"] == g.season) & (rosters["team"] == team)
                            & (rosters["position"] == "QB") & (rosters["week"] <= g.week)]
                cands = r[r["week"] == r["week"].max()]["gsis_id"].dropna().unique()
                cands = [c for c in cands if c not in excl]
                act = max(cands, key=lambda c: qbm.dropbacks_before(c, date)) if cands else None
            v_exp, v_act = qbm.value(exp, date), qbm.value(act, date)
            changed = int(exp is not None and act != exp)
            rows.append({"game_id": g.game_id, "team": team, "qb_change": changed,
                         "qb_delta": (v_exp - v_act) if changed else 0.0, "qb_value": v_act,
                         "qb_exp": qbm.name(exp), "qb_act": qbm.name(act)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 6. Elo (estilo FiveThirtyEight, con margen de victoria y regresión anual)
# ---------------------------------------------------------------------------
def elo_ratings(schedules: pd.DataFrame) -> pd.DataFrame:
    s = schedules.sort_values(["gameday", "game_id"])
    elo, season, rows = {}, None, []
    for g in s.itertuples():
        if g.season != season:  # regresión a la media entre temporadas
            elo = {t: C.ELO_MEAN * C.ELO_REVERT + v * (1 - C.ELO_REVERT) for t, v in elo.items()}
            season = g.season
        h, a = elo.get(g.home_team, C.ELO_MEAN), elo.get(g.away_team, C.ELO_MEAN)
        rows.append((g.game_id, h - a))
        if pd.notna(g.result):
            hfa = 0 if g.location == "Neutral" else C.ELO_HFA
            diff = h + hfa - a
            exp = 1 / (1 + 10 ** (-diff / 400))
            res = 1.0 if g.result > 0 else (0.0 if g.result < 0 else 0.5)
            fav_diff = diff if res == 1 else -diff
            mov = np.log(abs(g.result) + 1) * 2.2 / (fav_diff * 0.001 + 2.2) if g.result else 1.0
            delta = C.ELO_K * mov * (res - exp)
            elo[g.home_team], elo[g.away_team] = h + delta, a - delta
    return pd.DataFrame(rows, columns=["game_id", "elo_diff"])


# ---------------------------------------------------------------------------
# 7. EPA ajustado por rival (ridge con efectos ataque/defensa y decaimiento temporal)
# ---------------------------------------------------------------------------
ADJ_TARGETS = {"epa": ("epa_sum", "plays"), "pass": ("pass_epa_sum", "pass_n"),
               "rush": ("rush_epa_sum", "rush_n"), "sr": ("succ_sum", "plays"),
               "st": ("st_net", "games")}


def opponent_adjusted(tg: pd.DataFrame, dates) -> pd.DataFrame:
    """Para cada fecha de partido, ajusta  y = media + ataque[equipo] + defensa[rival] + local
    sobre los partidos ANTERIORES a esa fecha, ponderando por jugadas y por antigüedad
    (vida media ADJ_HALF_LIFE días). La penalización ridge encoge hacia la media de la liga,
    así que funciona también como prior al inicio de temporada."""
    from sklearn.linear_model import Ridge

    teams = sorted(set(tg["team"]) | set(tg["opp"]))
    ix = {t: i for i, t in enumerate(teams)}
    T = len(teams)
    ti, oi = tg["team"].map(ix).values, tg["opp"].map(ix).values
    home = np.where(tg["is_home"].values == 1, 1.0, -1.0)
    gd = tg["gameday"].values
    out = []
    for d in sorted(pd.to_datetime(pd.Series(dates).unique())):
        m = (gd < np.datetime64(d)) & (gd >= np.datetime64(d - pd.Timedelta(days=C.ADJ_WINDOW_DAYS)))
        if m.sum() < 2 * T:
            continue
        n = m.sum()
        X = np.zeros((n, 2 * T + 1))
        r = np.arange(n)
        X[r, ti[m]] = 1.0
        X[r, T + oi[m]] = 1.0
        X[:, 2 * T] = home[m]
        age = (np.datetime64(d) - gd[m]) / np.timedelta64(1, "D")
        decay = 0.5 ** (age / C.ADJ_HALF_LIFE)
        rec = {"gameday": d}
        res = {}
        for name, (num, den) in ADJ_TARGETS.items():
            nn = tg[den].values[m].astype(float)
            ok = nn > 0
            y = np.where(ok, tg[num].values[m] / np.where(ok, nn, 1), 0.0)
            w = decay * nn
            w = w / w[ok].mean()
            rg = Ridge(alpha=C.ADJ_ALPHA).fit(X[ok], y[ok], sample_weight=w[ok])
            res[name] = rg.coef_
        for t, i in ix.items():
            row = dict(rec, team=t)
            for name, coef in res.items():
                row[f"adj_off_{name}"] = coef[i]
                row[f"adj_def_{name}"] = coef[T + i]
            out.append(row)
    return pd.DataFrame(out)


# ---------------------------------------------------------------------------
# 8. Ensamblado del dataset a nivel partido
# ---------------------------------------------------------------------------
FORM = ["streak", "last4_win", "last4_pd", "epa_trend"]
CONTEXT = ["hfa", "is_neutral", "rest_diff", "div_game", "indoor", "wind", "temp_extreme",
           "precip", "weather_pen", "d_weather_exposure", "d_inj_off", "d_inj_def",
           "d_qb_delta", "home_qb_change", "away_qb_change", "d_adj_net_epa"]
FEATURES_V1 = ([f"d_{w}_{m}" for w in ("b", "r") for m in MODEL_METRICS]
               + [f"d_{f}" for f in FORM] + CONTEXT)
# v2: conjunto compacto elegido por validación temporal (log loss 0.646 -> 0.618).
# Las variables de v1 se siguen calculando (útiles para análisis), pero no entran al modelo.
# Todas son antisimétricas (cambian de signo si se invierten local y visitante), lo que
# permite entrenar el modelo de margen de forma simétrica y tratar bien las sedes neutrales.
FEATURES = ["elo_diff", "d_adj_net_epa", "d_oa_pass", "d_oa_sr", "home_field", "hfa",
            "rest_diff", "d_qb_delta", "d_inj_off", "d_inj_def"]


def build_dataset(data, rolling_n: int = C.ROLLING_N, weather_overrides: dict | None = None,
                  target: tuple[int, int] | None = None,
                  manual_qb_out: list[str] | None = None,
                  manual_qb_start: dict | None = None,
                  extra_injuries: pd.DataFrame | None = None) -> pd.DataFrame:
    sched = data.schedules[data.schedules["season"] >= min(C.WARMUP_SEASONS)].copy()
    injuries = data.injuries
    if extra_injuries is not None and not extra_injuries.empty:
        injuries = pd.concat([injuries, extra_injuries], ignore_index=True)

    tg = team_game_stats(data.pbp, sched)
    states, prior = team_states(tg, rolling_n)
    sides = _game_sides(sched)[["game_id", "season", "week", "gameday", "team", "is_home"]]
    sf = side_features(sides, states, prior)

    oa = opponent_adjusted(tg, sched["gameday"])
    inj = nonqb_injury_loss(injuries, data.snaps, data.rosters)
    qbm = QBModel(data.pbp, data.rosters)
    qbf = qb_features(sched, qbm, injuries, data.rosters, target, manual_qb_out, manual_qb_start)

    sf = (sides.merge(sf, on=["game_id", "team"])
          .merge(oa, on=["gameday", "team"], how="left")
          .merge(inj, on=["season", "week", "team"], how="left")
          .merge(qbf, on=["game_id", "team"], how="left"))
    sf[["inj_off", "inj_def"]] = sf[["inj_off", "inj_def"]].fillna(0)
    sf[["qb_change", "qb_delta"]] = sf[["qb_change", "qb_delta"]].fillna(0)
    sf["qb_value"] = sf["qb_value"].fillna(C.QB_REPLACEMENT_EPA)

    H = sf[sf["is_home"] == 1].drop(columns=["is_home"]).add_prefix("h_")
    A = sf[sf["is_home"] == 0].drop(columns=["is_home"]).add_prefix("a_")
    df = (sched.merge(H, left_on="game_id", right_on="h_game_id")
          .merge(A, left_on="game_id", right_on="a_game_id"))

    diffs = {f"d_{w}_{m}": (-1 if m in LOWER_IS_BETTER else 1) * (df[f"h_{w}_{m}"] - df[f"a_{w}_{m}"])
             for w in ("b", "r") for m in METRICS}
    diffs.update({f"d_{f}": df[f"h_{f}"] - df[f"a_{f}"] for f in FORM})
    df = pd.concat([df, pd.DataFrame(diffs, index=df.index)], axis=1)

    df = df.merge(home_field_advantage(data.schedules), on="game_id", how="left")
    df = df.merge(weather_features(sched, data.pbp, weather_overrides), on="game_id",
                  how="left", suffixes=("_sched", ""))
    df = df.copy()
    df["home_field"] = 1 - df["is_neutral"]   # 1 = hay local real, 0 = sede neutral
    df["rest_diff"] = (df["home_rest"] - df["away_rest"]).fillna(0).clip(-7, 7)
    df["div_game"] = df["div_game"].fillna(0)

    # Clima: el equipo que más depende del pase sufre más la penalización
    df["d_weather_exposure"] = (df["a_b_pass_rate"] - df["h_b_pass_rate"]) * df["weather_pen"]
    df["d_inj_off"] = df["a_inj_off"] - df["h_inj_off"]
    df["d_inj_def"] = df["a_inj_def"] - df["h_inj_def"]
    df["d_qb_delta"] = df["a_qb_delta"] - df["h_qb_delta"]
    df["d_qb_value"] = df["h_qb_value"] - df["a_qb_value"]
    df["home_qb_change"], df["away_qb_change"] = df["h_qb_change"], df["a_qb_change"]

    # EPA ajustado por rival: positivo = ventaja local (ataque propio + defensa propia)
    for k in ADJ_TARGETS:
        df[f"d_oa_{k}"] = ((df[f"h_adj_off_{k}"] - df[f"h_adj_def_{k}"])
                           - (df[f"a_adj_off_{k}"] - df[f"a_adj_def_{k}"]))
    df["d_oa_net_epa"] = df.pop("d_oa_epa")

    # EPA neto ajustado por rival + clima + lesiones + QB: la feature "resumen"
    for s in ("h", "a"):
        pr = df[f"{s}_b_pass_rate"]
        off = (df[f"{s}_adj_off_epa"].fillna(0) - pr * df["weather_pen"]
               - df[f"{s}_inj_off"] - df[f"{s}_qb_delta"] * pr)
        df[f"{s}_adj_net_epa"] = off - (df[f"{s}_adj_def_epa"].fillna(0) + df[f"{s}_inj_def"])
    df["d_adj_net_epa"] = df["h_adj_net_epa"] - df["a_adj_net_epa"]
    df = df.merge(elo_ratings(data.schedules), on="game_id", how="left")

    df["home_win"] = np.where(df["result"] > 0, 1.0, np.where(df["result"] < 0, 0.0, np.nan))
    return df.sort_values(["gameday", "game_id"]).reset_index(drop=True)
