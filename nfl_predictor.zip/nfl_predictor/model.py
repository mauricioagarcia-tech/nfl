"""Entrenamiento, validación temporal, evaluación y exportación del modelo.

Modelo por defecto (v2): regresión ridge sobre el margen de puntos convertida a
probabilidad, compitiendo contra regresión logística y LightGBM.

Validación: walk-forward por temporada (expanding window). Para validar la temporada S
sólo se entrena con temporadas < S, y las features ya son "pre-partido", así que no
hay fuga de información futura en ninguna dirección.

Uso:
    python model.py                 # descarga/actualiza datos, valida y guarda el modelo
    python model.py --rolling-n 6   # cambia la ventana móvil
"""
from __future__ import annotations

import argparse
import logging
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import accuracy_score, brier_score_loss, log_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

import config as C
from features import FEATURES, build_dataset

log = logging.getLogger(__name__)

try:
    from lightgbm import LGBMClassifier
except ImportError:  # LightGBM es opcional
    LGBMClassifier = None


# ---------------------------------------------------------------------------
# Modelo de margen: Ridge sobre el diferencial de puntos -> probabilidad con N(0, sigma)
# ---------------------------------------------------------------------------
class MarginModel(BaseEstimator, ClassifierMixin):
    """Predice el margen esperado del local (puntos) con regresión ridge y lo convierte
    en probabilidad: P(local) = Phi(margen / sigma), con sigma = desviación de los residuos
    (~13 pts en la NFL). Aprovecha más información que un clasificador binario: ganar por
    20 no es lo mismo que ganar por 1.

    Entrenamiento simétrico: cada partido se duplica con local/visitante invertidos
    (features y margen con signo cambiado) y sin intercepto. Así la ventaja de jugar en
    casa la aprenden sólo `home_field` y `hfa`, y en sede neutral desaparece."""
    uses_margin = True

    def __init__(self, alpha: float = 30.0):
        self.alpha = alpha

    def fit(self, X, y):
        X = pd.DataFrame(X).fillna(0.0)
        y = np.asarray(y, dtype=float)
        Xa, ya = pd.concat([X, -X], ignore_index=True), np.concatenate([y, -y])
        self.pipe_ = Pipeline([("impute", SimpleImputer(strategy="constant", fill_value=0.0)),
                               ("scale", StandardScaler(with_mean=False)),
                               ("reg", Ridge(alpha=2 * self.alpha, fit_intercept=False))])
        self.pipe_.fit(Xa, ya)
        self.sigma_ = float(np.std(y - self.pipe_.predict(X)))
        self.classes_ = np.array([0.0, 1.0])
        return self

    def predict_margin(self, X) -> np.ndarray:
        return self.pipe_.predict(pd.DataFrame(X).fillna(0.0))

    def predict_proba(self, X) -> np.ndarray:
        p = norm.cdf(self.predict_margin(pd.DataFrame(X).fillna(0.0)) / self.sigma_)
        return np.column_stack([1 - p, p])


def _target(mdl, frame: pd.DataFrame) -> pd.Series:
    return frame["result"] if getattr(mdl, "uses_margin", False) else frame["home_win"]


# ---------------------------------------------------------------------------
# Candidatos
# ---------------------------------------------------------------------------
def candidates() -> dict:  # (v2) se conserva para comparaciones manuales
    models = {f"margen_ridge_a{a}": MarginModel(alpha=a) for a in (10, 30, 100)}
    models |= {
        f"logreg_C{c}": Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
            ("clf", LogisticRegression(C=c, max_iter=5000)),
        ]) for c in (0.02, 0.05, 0.2)
    }
    if LGBMClassifier is not None:
        models["lightgbm"] = LGBMClassifier(
            n_estimators=250, learning_rate=0.02, num_leaves=7, max_depth=3,
            min_child_samples=40, subsample=0.8, subsample_freq=1,
            colsample_bytree=0.6, reg_lambda=10.0, verbose=-1, random_state=42)
    return models


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def training_frame(df: pd.DataFrame) -> pd.DataFrame:
    tr = df[df["season"].isin(C.TRAIN_SEASONS) & df["home_win"].notna()]
    return tr.sort_values(["gameday", "game_id"]).reset_index(drop=True)


def market_prob(df: pd.DataFrame) -> pd.Series:
    """Probabilidad implícita (sin vig) de las moneylines: sólo como benchmark."""
    def implied(ml):
        return np.where(ml < 0, -ml / (-ml + 100), 100 / (ml + 100))
    h, a = implied(df["home_moneyline"].astype(float)), implied(df["away_moneyline"].astype(float))
    return pd.Series(h / (h + a), index=df.index)


def scores(y, p) -> dict:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return {"log_loss": log_loss(y, p, labels=[0, 1]), "accuracy": accuracy_score(y, p > 0.5),
            "roc_auc": roc_auc_score(y, p) if len(set(y)) > 1 else np.nan,
            "brier": brier_score_loss(y, p), "n": len(y)}


# ---------------------------------------------------------------------------
# Espacio de búsqueda (se elige con validación ANIDADA, ver nested_selection)
# ---------------------------------------------------------------------------
FEATURE_SETS = {
    "base": FEATURES,
    "base+qb": FEATURES + ["d_qb_value"],
    "base+qb+st": FEATURES + ["d_qb_value", "d_oa_st"],
}
PARAM_GRID = [{"QB_HALF_LIFE": q, "ADJ_HALF_LIFE": a}
              for q in (180.0, 365.0, 730.0) for a in (70.0, 100.0, 150.0)]


def search_models() -> dict:
    return {**{f"margen_ridge_a{a}": MarginModel(alpha=a) for a in (10, 30, 100)},
            "logreg_C0.05": Pipeline([("impute", SimpleImputer(strategy="median")),
                                      ("scale", StandardScaler()),
                                      ("clf", LogisticRegression(C=0.05, max_iter=5000))])}


def apply_params(params: dict) -> None:
    for k, v in params.items():
        setattr(C, k, v)


def walk_forward(tr: pd.DataFrame, feats: list[str], mdl) -> pd.Series:
    """Predicciones fuera de muestra: cada temporada S se predice con un modelo
    entrenado sólo con temporadas < S."""
    oof = pd.Series(np.nan, index=tr.index)
    for val in sorted(tr["season"].unique())[1:]:
        fit, ev = tr[tr["season"] < val], tr[tr["season"] == val]
        mdl.fit(fit[feats], _target(mdl, fit))
        oof.loc[ev.index] = mdl.predict_proba(ev[feats])[:, 1]
    return oof


def _ll(y, p) -> float:
    return log_loss(y, np.clip(p, 1e-6, 1 - 1e-6), labels=[0, 1])


def nested_selection(oof: dict, tr: pd.DataFrame, inner_k: int = 2) -> pd.DataFrame:
    """Validación anidada: para evaluar la temporada S, la configuración (parámetros +
    variables + algoritmo) se elige SOLO con las temporadas S-2 y S-1. El resultado es
    una estimación honesta: ningún hiperparámetro 've' la temporada con la que se evalúa."""
    rows = []
    seasons = sorted(tr["season"].unique())
    for S in seasons[1 + inner_k:]:
        inner = tr["season"].isin(range(S - inner_k, S))
        best = min(oof, key=lambda k: _ll(tr.loc[inner, "home_win"], oof[k][inner]))
        out = tr["season"] == S
        y = tr.loc[out, "home_win"]
        mk = market_prob(tr[out]).dropna()
        rows.append({"temporada": S, "config_elegida": " | ".join(best), "n": int(out.sum()),
                     "log_loss": _ll(y, oof[best][out]), "accuracy": accuracy_score(y, oof[best][out] > 0.5),
                     "mkt_log_loss": _ll(tr.loc[mk.index, "home_win"], mk),
                     "mkt_accuracy": accuracy_score(tr.loc[mk.index, "home_win"], mk > 0.5),
                     "_p": oof[best][out].values, "_y": y.values})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Entrenamiento
# ---------------------------------------------------------------------------
def train(data, save: bool = True, rolling_n: int = C.ROLLING_N,
          until: pd.Timestamp | None = None) -> dict:
    """Busca la mejor configuración (parámetros x variables x algoritmo), mide su
    rendimiento con validación anidada y entrena el modelo final con todos los datos.
    `until`: sólo usa partidos anteriores a esa fecha (backtest honesto)."""
    oof, frames = {}, {}
    for i, params in enumerate(PARAM_GRID):
        apply_params(params)
        df = build_dataset(data, rolling_n=rolling_n)
        tr = training_frame(df if until is None else df[df["gameday"] < until])
        frames[i] = tr
        for fs_name, feats in FEATURE_SETS.items():
            for m_name, mdl in search_models().items():
                key = (f"QB_HL={params['QB_HALF_LIFE']:.0f} ADJ_HL={params['ADJ_HALF_LIFE']:.0f}",
                       fs_name, m_name)
                oof[key] = walk_forward(tr, feats, mdl)
        log.info("Grid %d/%d listo", i + 1, len(PARAM_GRID))
    tr = frames[0]
    nested = nested_selection(oof, tr)

    # Configuración final: la mejor en las últimas 4 temporadas
    recent = tr["season"] >= tr["season"].max() - 3
    best = min(oof, key=lambda k: _ll(tr.loc[recent, "home_win"], oof[k][recent]))
    p_idx = [k for k in oof].index(best) // (len(FEATURE_SETS) * len(search_models()))
    params, feats = PARAM_GRID[p_idx], FEATURE_SETS[best[1]]
    apply_params(params)
    tr = frames[p_idx]
    final = search_models()[best[2]]
    final.fit(tr[feats], _target(final, tr))

    p_all, y_all = np.concatenate(nested["_p"]), np.concatenate(nested["_y"])
    bundle = {
        "model": final, "name": best[2], "features": feats, "feature_set": best[1],
        "params": params, "rolling_n": rolling_n, "n_train": len(tr),
        "nested": nested.drop(columns=["_p", "_y"]),
        "nested_pooled": scores(y_all, p_all),
        "fixed_v2_recent": scores(tr.loc[recent, "home_win"],
                                  oof[("QB_HL=365 ADJ_HL=100", "base", "margen_ridge_a100")][recent]),
        "best_recent": scores(tr.loc[recent, "home_win"], oof[best][recent]),
        "trained_through": str(tr["gameday"].max().date()),
        "trained_at": datetime.now().isoformat(timespec="seconds"),
    }
    if save:
        joblib.dump(bundle, C.MODEL_PATH)
        log.info("Modelo guardado en %s", C.MODEL_PATH)
    return bundle


def load_model() -> dict | None:
    if not C.MODEL_PATH.exists():
        return None
    try:
        return joblib.load(C.MODEL_PATH)
    except Exception as exc:  # p.ej. modelo guardado con otra versión de scikit-learn
        log.warning("No se pudo cargar el modelo (%s); se reentrenará.", exc)
        return None


def predict_proba(bundle: dict, X: pd.DataFrame) -> np.ndarray:
    """P(gana local). P(gana visitante) = 1 - P(local) -> suman 100% por construcción."""
    return bundle["model"].predict_proba(X[bundle["features"]])[:, 1]


def predict_margin(bundle: dict, X: pd.DataFrame) -> np.ndarray | None:
    mdl = bundle["model"]
    if isinstance(mdl, MarginModel):
        return mdl.predict_margin(X[bundle["features"]])
    # clasificador: margen equivalente con la desviación típica de la NFL (~13.5 pts)
    p = np.clip(predict_proba(bundle, X), 1e-4, 1 - 1e-4)
    return norm.ppf(p) * 13.5


def explain(bundle: dict, X: pd.DataFrame) -> pd.DataFrame:
    """Contribución de cada feature al log-odds del local (positivo = favorece al local)."""
    mdl, feats = bundle["model"], bundle["features"]
    if isinstance(mdl, MarginModel):  # puntos -> log-odds aprox. (probit ~ logit * 1.7)
        p = mdl.pipe_
        z = p.named_steps["scale"].transform(p.named_steps["impute"].transform(X[feats]))
        contrib = z * p.named_steps["reg"].coef_ * 1.7 / mdl.sigma_
    elif isinstance(mdl, Pipeline):
        z = mdl.named_steps["scale"].transform(mdl.named_steps["impute"].transform(X[feats]))
        contrib = z * mdl.named_steps["clf"].coef_[0]
    else:  # LightGBM: valores SHAP nativos
        contrib = mdl.predict(X[feats], pred_contrib=True)[:, :-1]
    return pd.DataFrame(contrib, columns=feats, index=X.index)


def report(bundle: dict) -> str:
    n = bundle["nested"].copy()
    for c in ("log_loss", "mkt_log_loss"):
        n[c] = n[c].map("{:.4f}".format)
    for c in ("accuracy", "mkt_accuracy"):
        n[c] = n[c].map("{:.1%}".format)
    p = bundle["nested_pooled"]
    return (f"\n== Validación anidada (estimación honesta) ==\n{n.to_string(index=False)}\n"
            f"Agregado: log loss {p['log_loss']:.4f} | accuracy {p['accuracy']:.1%} | "
            f"AUC {p['roc_auc']:.3f} | n={p['n']}\n"
            f"\nConfiguración final: {bundle['name']} | variables: {bundle['feature_set']} | "
            f"params: {bundle['params']}\nPartidos de entrenamiento: {bundle['n_train']} | "
            f"datos hasta: {bundle['trained_through']}\n")


if __name__ == "__main__":
    from data_loader import load_all

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    ap = argparse.ArgumentParser(description="Entrena el modelo NFL")
    ap.add_argument("--rolling-n", type=int, default=C.ROLLING_N)
    ap.add_argument("--no-refresh", action="store_true", help="usa sólo la caché local")
    args = ap.parse_args()
    data = load_all(refresh=not args.no_refresh)
    import model as _self  # para que el pickle referencie model.MarginModel, no __main__
    b = _self.train(data, rolling_n=args.rolling_n)
    print(_self.report(b))
