"""Descarga y cachea los datos de nflverse.

Backend:
  * `nfl_data_py` (lo pedido). Está archivado por nflverse y fija pandas<2 / numpy<2,
    así que sólo se instala en Python <= 3.11.
  * `nflreadpy` (su sucesor oficial, basado en polars). Se usa automáticamente si
    `nfl_data_py` no está instalado. Fuerza uno u otro con NFL_BACKEND=nfl_data_py|nflreadpy.

Ambos leen exactamente los mismos archivos de nflverse, así que las columnas coinciden.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from datetime import datetime, timedelta

import pandas as pd
import requests

from config import (CACHE_DIR, CURRENT_SEASON, HFA_START_SEASON, STADIUMS,
                    TRAIN_SEASONS, WARMUP_SEASONS)

log = logging.getLogger(__name__)

PBP_COLS = [
    "game_id", "season", "season_type", "week", "game_date", "posteam", "defteam",
    "play_type", "pass", "rush", "qb_dropback", "epa", "success", "cpoe",
    "yardline_100", "down", "fixed_drive", "fixed_drive_result",
    "third_down_converted", "third_down_failed", "fourth_down_converted",
    "fourth_down_failed", "interception", "fumble_lost", "fumbled_1_team",
    "passer_id", "passer", "weather", "temp", "wind", "roof", "wp",
]


# ---------------------------------------------------------------------------
# Backend
# ---------------------------------------------------------------------------
def _backend():
    pref = os.getenv("NFL_BACKEND", "auto").lower()
    if pref in ("auto", "nfl_data_py"):
        try:
            import nfl_data_py as ndp  # noqa: F401
            return "nfl_data_py", ndp
        except ImportError:
            if pref == "nfl_data_py":
                raise
    import nflreadpy as nrp
    return "nflreadpy", nrp


def _fetch(kind: str, years: list[int] | None = None) -> pd.DataFrame:
    name, lib = _backend()
    if name == "nfl_data_py":
        fn = {
            "pbp": lambda: lib.import_pbp_data(years, columns=PBP_COLS, downcast=True, cache=False),
            "schedules": lambda: lib.import_schedules(years),
            "injuries": lambda: lib.import_injuries(years),
            "snaps": lambda: lib.import_snap_counts(years),
            "rosters": lambda: lib.import_weekly_rosters(years),
        }[kind]
        return fn()
    fn = {
        "pbp": lambda: lib.load_pbp(years),
        "schedules": lambda: lib.load_schedules(years),
        "injuries": lambda: lib.load_injuries(years),
        "snaps": lambda: lib.load_snap_counts(years),
        "rosters": lambda: lib.load_rosters_weekly(years),
    }[kind]
    df = fn().to_pandas()
    if kind == "pbp":
        df = df[[c for c in PBP_COLS if c in df.columns]]
    return df


def _normalize(df: pd.DataFrame) -> pd.DataFrame:
    """Unifica tipos de texto (Arrow/StringDtype -> object) para que caché y descarga
    fresca concatenen y hagan merge sin conflictos de dtype."""
    for c in df.columns:
        if isinstance(df[c].dtype, pd.StringDtype) or str(df[c].dtype) in ("string", "large_string", "str"):
            df[c] = df[c].astype(object)
    return df


def _cached(kind: str, season: int, refresh: bool) -> pd.DataFrame:
    """Un parquet por (dataset, temporada). La temporada en curso se refresca siempre
    que refresh=True; las temporadas cerradas se descargan una sola vez."""
    path = CACHE_DIR / f"{kind}_{season}.parquet"
    if path.exists() and not (refresh and season == CURRENT_SEASON):
        return _normalize(pd.read_parquet(path))
    log.info("Descargando %s %s ...", kind, season)
    try:
        df = _fetch(kind, [season])
    except Exception as exc:  # p.ej. lesiones aún no publicadas
        log.warning("No se pudo descargar %s %s: %s", kind, season, exc)
        return _normalize(pd.read_parquet(path)) if path.exists() else pd.DataFrame()
    df = _normalize(df)
    df.to_parquet(path, index=False)
    return df


def _multi(kind: str, seasons: list[int], refresh: bool) -> pd.DataFrame:
    frames = [_cached(kind, s, refresh) for s in seasons]
    frames = [f for f in frames if not f.empty]
    return _normalize(pd.concat(frames, ignore_index=True)) if frames else pd.DataFrame()


# ---------------------------------------------------------------------------
# API pública
# ---------------------------------------------------------------------------
@dataclass
class NFLData:
    pbp: pd.DataFrame
    schedules: pd.DataFrame
    injuries: pd.DataFrame
    snaps: pd.DataFrame
    rosters: pd.DataFrame


def load_all(refresh: bool = True, current_season: int = CURRENT_SEASON) -> NFLData:
    seasons = sorted(set(WARMUP_SEASONS + TRAIN_SEASONS + [current_season]))
    sched_seasons = list(range(HFA_START_SEASON, current_season + 1))

    pbp = _multi("pbp", seasons, refresh)
    schedules = _multi("schedules", sched_seasons, refresh)
    injuries = _multi("injuries", seasons, refresh)
    snaps = _multi("snaps", seasons, refresh)
    rosters = _multi("rosters", seasons, refresh)

    schedules["gameday"] = pd.to_datetime(schedules["gameday"])
    pbp = pbp[pbp["season_type"].isin(["REG", "POST"])].copy()
    log.info("pbp=%s jugadas | calendario=%s partidos | lesiones=%s filas",
             len(pbp), len(schedules), len(injuries))
    return NFLData(pbp, schedules, injuries, snaps, rosters)


def load_teams() -> pd.DataFrame:
    """Nombres y colores de los equipos (para la interfaz web)."""
    path = CACHE_DIR / "teams.parquet"
    if path.exists():
        return pd.read_parquet(path)
    name, lib = _backend()
    try:
        df = lib.import_team_desc() if name == "nfl_data_py" else lib.load_teams().to_pandas()
    except Exception as exc:
        log.warning("No se pudo descargar la tabla de equipos: %s", exc)
        return pd.DataFrame(columns=["team_abbr", "team_name", "team_color"])
    df = _normalize(df)
    df.to_parquet(path, index=False)
    return df


# ---------------------------------------------------------------------------
# Clima: pronóstico (Open-Meteo, gratis y sin API key)
# ---------------------------------------------------------------------------
OPEN_METEO = "https://api.open-meteo.com/v1/forecast"


def fetch_forecast(team: str, gameday: pd.Timestamp, gametime: str | None) -> dict | None:
    """Pronóstico horario en el estadio del local a la hora del kickoff (hora del Este).
    Open-Meteo cubre ~16 días hacia adelante. Devuelve None si no hay datos."""
    if team not in STADIUMS:
        return None
    lat, lon, _ = STADIUMS[team]
    day = pd.Timestamp(gameday).date()
    if day > (datetime.now() + timedelta(days=15)).date():
        return None
    hour = int(str(gametime or "13:00").split(":")[0])
    params = {
        "latitude": lat, "longitude": lon,
        "hourly": "temperature_2m,relative_humidity_2m,precipitation,snowfall,wind_speed_10m",
        "temperature_unit": "fahrenheit", "wind_speed_unit": "mph",
        "precipitation_unit": "mm", "timezone": "America/New_York",
        "start_date": day.isoformat(), "end_date": day.isoformat(),
    }
    try:
        r = requests.get(OPEN_METEO, params=params, timeout=15)
        r.raise_for_status()
        h = r.json()["hourly"]
    except Exception as exc:
        log.warning("Pronóstico no disponible para %s %s (%s)", team, day, type(exc).__name__)
        return None
    # promedio de las ~3 horas de partido
    idx = [i for i in range(hour, min(hour + 3, len(h["time"])))]
    avg = lambda k: float(pd.Series([h[k][i] for i in idx]).mean())  # noqa: E731
    precip, snow = avg("precipitation"), avg("snowfall")
    level = 2 if (snow > 0.2 or precip >= 2.5) else (1 if precip >= 0.3 else 0)
    return {"temp": avg("temperature_2m"), "wind": avg("wind_speed_10m"),
            "humidity": avg("relative_humidity_2m"), "precip": level, "source": "open-meteo"}


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    d = load_all(refresh=True)
    print(f"Backend: {_backend()[0]}")
    for k in ("pbp", "schedules", "injuries", "snaps", "rosters"):
        print(f"{k:10s} {getattr(d, k).shape}")
