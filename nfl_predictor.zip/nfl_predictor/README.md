# NFL Win Probability · predicción semanal

## Instalación
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Uso
```bash
python data_loader.py                 # (opcional) descarga y cachea 2022-2026 en ./cache
python model.py                       # validación temporal + guarda models/nfl_win_model.joblib
python predict_week.py                # semana actual (la próxima sin jugar)
python predict_week.py --week 8       # semana concreta
python predict_week.py --week 8 --qb-out KC --injuries-file lesiones.csv
python predict_week.py --week 5       # semana ya jugada = backtest (entrena sólo con datos previos)
# Si cambias config.py (temporadas, columnas de pbp), borra ./cache para volver a descargar.
```
Opciones útiles: `--rolling-n 6` (ventana móvil), `--retrain`, `--no-refresh` (sólo caché),
`--no-weather-api`, `-v` (logs). La tabla se guarda también en `output/predicciones_<año>_wNN.csv`.

`lesiones.csv` (para reportes de último minuto): columnas `team,full_name,position,report_status`
con `report_status` en `Out | Doubtful | Questionable`.

## Interfaz web (página interactiva)
```bash
streamlit run app.py          # se abre en http://localhost:8501
```
* **Semana**: tarjetas con la probabilidad de cada equipo, pick, margen, línea de Vegas, QBs y factores
  clave. En la barra lateral: elegir semana, "Calcular predicciones" y ajustes de último minuto
  (equipos sin su QB, QB que regresa como `BAL=Lamar Jackson`, CSV de lesiones, clima).
* **Récord**: aciertos/fallos acumulados vs. el mercado, gráfica semana a semana y tabla de partidos.
  Los resultados se califican solos con los marcadores de nflverse.
* **Modelo**: configuración elegida y validación anidada. Botón "Reentrenar" (~3 min).

El historial vive en `history/predicciones.csv`. Una predicción se puede actualizar hasta el kickoff;
después queda congelada, para que el récord sea honesto. Las semanas calculadas cuando ya se jugaron
se marcan como *backtest* y no cuentan en el récord (hay un interruptor para verlas).

### Que se actualice solo
* **En tu computadora**: programa `python update.py` (cron en Mac/Linux, Programador de tareas en
  Windows) los martes con `--retrain`, y jueves/domingo/lunes sin él. Ejemplo cron:
  `0 10 * * 0,1,4 cd /ruta/nfl_predictor && .venv/bin/python update.py`
* **Página en internet, gratis y sin tu computadora**: sube la carpeta a un repositorio de GitHub,
  el workflow `.github/workflows/actualizar.yml` ejecuta `update.py` en esos horarios y guarda el
  historial en el repo; luego publica `app.py` en Streamlit Community Cloud (share.streamlit.io,
  "New app" → tu repositorio → `app.py`). Cada vez que el workflow hace commit, la página se actualiza.

## Estructura
| Archivo | Contenido |
|---|---|
| `config.py` | Temporadas, rutas, pesos heurísticos (clima, lesiones, QB) y coordenadas de estadios |
| `data_loader.py` | play-by-play, calendarios, rosters semanales, snaps y lesiones (nflverse) + pronóstico Open-Meteo |
| `features.py` | EPA pase/carrera, Success Rate, CPOE, 3ª/4ª, zona roja, turnovers, forma, localía, clima, lesiones |
| `model.py` | Regresión logística regularizada vs. LightGBM, CV walk-forward por temporada, métricas, exportación |
| `predict_week.py` | Motor `run_week()` + CLI con tabla de probabilidades y factores clave |
| `tracker.py` | Historial de predicciones, congelamiento al kickoff y récord vs. mercado |
| `update.py` | Actualizador automático (datos → calificar → predecir → guardar) |
| `app.py` | Página web interactiva (Streamlit) |

## Modelo v3 (actual)
* **QB v2**: valor = EPA/dropback + 0.004·CPOE, ponderado por recencia (vida media elegida por CV)
  y con prior según el pick de draft para novatos/suplentes. Nueva variable `d_qb_value`
  (calidad del QB titular local − visitante).
* **Equipos especiales**: EPA de goles de campo, PAT, despejes y patadas, ajustado por rival
  (`d_oa_st`). Se calcula siempre; entra al modelo sólo si la validación lo elige.
* **Validación anidada**: `model.py` prueba 9 combinaciones de parámetros × 3 conjuntos de variables
  × 4 algoritmos. Para medir la temporada S, la configuración se elige sólo con S-2 y S-1, así el
  reporte es una estimación honesta. El modelo final usa la mejor configuración de las últimas
  4 temporadas. Entrenar tarda ~3 minutos.

## Modelo v2
* **Algoritmo**: ridge sobre el margen de puntos -> probabilidad con N(0, σ≈13), entrenado de forma
  simétrica (local/visitante invertidos) para tratar bien las sedes neutrales. Compite en la CV contra
  regresión logística y LightGBM; gana el de menor Log Loss.
* **10 variables**: Elo, EPA neto ajustado por rival (+ clima, lesiones y QB), EPA de pase y Success Rate
  ajustados por rival, localía (general y específica del equipo), descanso, cambio de QB y lesiones.
* **Datos**: entrenamiento 2019–2026 (2018 de calentamiento; calendarios desde 2012 para Elo y localía).
* **EPA ajustado por rival**: ridge con efectos de ataque/defensa por equipo, decaimiento temporal
  (vida media 100 días) y sin garbage time (probabilidad de victoria fuera de 5–95%).
* La tabla muestra también el margen proyectado y la probabilidad implícita del mercado como referencia.

## Notas de diseño
* **Sin leakage**: cada partido usa el estado del equipo tras su último partido completado
  (`merge_asof` estricto); la CV entrena con temporadas < S para validar S.
* **Inicio de temporada**: las métricas se mezclan con la temporada anterior regresada a la media
  (`PRIOR_K`, `PRIOR_REGRESS`), por eso se carga 2022 como calentamiento.
* **QB**: titular esperado = líder en dropbacks de los últimos 3 partidos; valor = EPA/dropback con
  shrinkage hacia un QB de reemplazo. Si el titular figura Out/Doubtful se usa el mejor QB del roster.
* **Resto de lesiones**: peso por posición × % de snaps reciente × probabilidad según el estatus.
* **Clima**: penalización de EPA por pase con viento > 15 mph y precipitación; ponderada por la
  dependencia del pase de cada equipo. Domos/techo cerrado = condiciones neutras.
* Los pesos de `config.py` son priors razonables, no estimaciones; el modelo aprende cuánto pesan.
